﻿using GMailProj.Workflow.Compose.Pages;
using GMailProj.Workflow.Login;
using GMailProj.Workflow.Login.Pages;
using System;
using TechTalk.SpecFlow;

namespace GMailProj.Workflow.Compose.Steps
{
    [Binding]
    public class ComposeMailSteps
    {

        private readonly ComposeMailPage _composeMailPage;
        private readonly LoginContext _loginContext;
        private readonly LoginPage _loginPage;

        public ComposeMailSteps(LoginPage loginPage, ComposeMailPage composeMailPage, LoginContext loginContext)
        {
            _composeMailPage = composeMailPage;
            _loginContext = loginContext;
            _loginPage = loginPage;
        }
        [Given(@"I Click on Compose Button")]
        [When(@"I Click on Compose Button")]
        public void WhenIClickOnComposeButton()
        {
            _composeMailPage.ComposeButtonClick();
            _loginPage.waitElement();
        }
        
        [When(@"I enter the to,subject and body")]
        public void WhenIEnterTheToSubjectAndBody(Table table)
        {
            _loginContext.username = table.Rows[0]["UserName"];
            _composeMailPage.EntertoDetails(_loginContext.username);
            _composeMailPage.EnterSubjectDetails();
            _composeMailPage.EnterMessageDetails();
        }
        
        [When(@"I click on send")]
        public void WhenIClickOnSend()
        {
            _composeMailPage.SendButtonClick();
            _loginPage.waitElement();
        }

        [Then(@"I should see the mail in the inbox")]
        public void ThenIShouldSeeTheMailInTheInbox()
        {
            if (_composeMailPage.verifyMailReceived())
                Console.WriteLine("Mail received");
        }


        //[Then(@"I should see a popup '(.*)'")]
        //public void ThenIShouldSeeAPopup(string p0)
        //{
        //    ScenarioContext.Current.Pending();
        //}
    }
}
