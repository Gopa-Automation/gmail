﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;

namespace GMailProj.Workflow.Compose.Pages
{
    public class ComposeMailPage
    {
        private By ToByXpath = By.XPath("//textarea[@name='to']");
        private By SubjectByXpath = By.XPath("//input[@name='subjectbox']");
        private By MessageByXpath = By.XPath("//div[@role='textbox']");
        private By SendButtonByXpath = By.XPath("//div[text()='Send']");
        private By ComposeButtonByXpath = By.XPath("//div[text()='Compose']");
        private string SubjectXpath = "//span/span[text()='{0}']";
        string subject;
        private readonly IWebDriver _webDriver;
        private readonly WebDriverWait _wait;

        public ComposeMailPage(IWebDriver webDriver, WebDriverWait wait)
        {
            _wait = wait;
            _webDriver = webDriver;

        }
        public void SendButtonClick()
        {
            var sendButton = SendButton;
            sendButton.Click();
        }

        public void ComposeButtonClick()
        {
            var composeButton = ComposeButton;
            composeButton.Click();
        }

        public void EntertoDetails(string toAddress)
        {
            var toAddressTextBox = ToAddressTextBox;
            toAddressTextBox.SendKeys(toAddress);

        }

        public void EnterSubjectDetails()
        {
            subject = "Subject_" + DateTime.Now.ToString("yyyyMMddHHmmssffff");
            var subjectTextBox = SubjectTextBox;
            subjectTextBox.SendKeys(subject);
        }

        public void EnterMessageDetails()
        {
            var messageTextBox = MessageTextBox;
            messageTextBox.SendKeys("Test the message");
        }

        private IWebElement ToAddressTextBox
        {
            get
            {
                return _wait.Until(d => d.FindElement(ToByXpath));
            }
        }

        private IWebElement SubjectTextBox
        {
            get
            {
                return _wait.Until(d => d.FindElement(SubjectByXpath));
            }
        }

        private IWebElement MessageTextBox
        {
            get
            {
                return _wait.Until(d => d.FindElement(MessageByXpath));
            }
        }


        private IWebElement SendButton
        {
            get
            {
                return _wait.Until(d => d.FindElement(SendButtonByXpath));
            }
        }

        private IWebElement ComposeButton
        {
            get
            {
                return _wait.Until(d => d.FindElement(ComposeButtonByXpath));
            }
        }

        public Boolean verifyComposeButtonExists()
        {
            return _wait.Until(d => d.FindElement(ComposeButtonByXpath)).Displayed;
        }

        public Boolean verifyMailReceived()
        {
            return _wait.Until(d => d.FindElement(SubjectMail(subject))).Displayed;
        }

        private By SubjectMail(string value)
        {
            return (By.XPath(string.Format(SubjectXpath, value)));
        }
    }
}
