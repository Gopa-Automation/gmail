﻿using GMailProj.Config;
using GMailProj.Framework;
using Microsoft.Extensions.Configuration;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Threading;

namespace GMailProj.Workflow.Login.Pages
{
    public class LoginPage
    {

        private By UserNameInputByXpath = By.XPath("//input[@type='email']");
        private By PasswordInputByXpath = By.XPath("//input[@type='password']");
        private By NextButtonByXpath = By.XPath("//span[text()='Next']");
        private By InvalidUserNameErrorMsgByXpath = By.XPath("//div[contains(text(),'find your Google Account')]");
        private By InvalidPasswordErrorMsgByXpath = By.XPath("//span[text()='Wrong password. Try again or click ‘Forgot password’ to reset it.']");
        private readonly ConfigSetting _configSetting;
        private readonly IWebDriver _webDriver;
        private readonly WebDriverWait _wait;
        public LoginPage(IWebDriver webDriver, WebDriverWait wait, ConfigSetting configSetting)
        {
            _webDriver = webDriver;
            _wait = wait;
            _configSetting = configSetting;
        }

        public void LaunchApplication()
        {
            string CurrentDirectory = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(CurrentDirectory).Parent.Parent.FullName;
            ConfigurationBuilder builder = new ConfigurationBuilder();
            builder.AddJsonFile(Path.Combine(projectDirectory, "AppConfig.json"));
            IConfigurationRoot configuration = builder.Build();
            configuration.Bind(_configSetting);
            _webDriver.Navigate().GoToUrl(_configSetting.AppURL);
        }

        public void UserNameInputSendKeys(string username)
        {
            var userNameInput = UserNameInput;
            userNameInput.SendKeys(username);
        }

        public void PasswordInputSendKeys(string password)
        {
            var passwordInput = PasswordInput;
            passwordInput.SendKeys(password);
        }

        public void NextButtonClick()
        {
            var nextButton = NextButton;
            nextButton.Click();
        }

        private IWebElement UserNameInput
        {
            get
            {
                return _wait.Until(d => d.FindElement(UserNameInputByXpath));
            }
        }

        private IWebElement PasswordInput
        {
            get
            {
                return _wait.Until(d => d.FindElement(PasswordInputByXpath));
            }
        }

        private IWebElement NextButton
        {
            get
            {
                return _wait.Until(d => d.FindElement(NextButtonByXpath));
            }
        }

        public void waitElement()
        {
            Thread.Sleep(10000);
        }
        public string getInvalidUserErrorMessage()
        {
            return _wait.Until(d => d.FindElement(InvalidUserNameErrorMsgByXpath)).Text;
        }
        public string getInvalidPasswordErrorMessage()
        {
            return _wait.Until(d => d.FindElement(InvalidPasswordErrorMsgByXpath)).Text;
        }

        
    }
}
