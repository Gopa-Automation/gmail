﻿using GMailProj.Framework;
using System;
using System.Collections.Generic;
using System.Text;

namespace GMailProj.Workflow.Login
{
    public class LoginContext
    {
        private readonly DataResolver _dataResolver;

        string UserName;
        string Password;

        public LoginContext(DataResolver dataResolver)
        {
            _dataResolver = dataResolver;
        }
        public string username
        {
            get { return UserName; }
            set { UserName = _dataResolver.Resolve(value); }
        }
        public string password
        {
            get { return Password; }
            set { Password = _dataResolver.Resolve(value); }
        }
    }
}
