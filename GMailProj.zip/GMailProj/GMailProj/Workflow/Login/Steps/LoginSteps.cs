﻿using GMailProj.Workflow.Compose.Pages;
using GMailProj.Workflow.Login.Pages;
using NUnit.Framework;
using System;
using TechTalk.SpecFlow;

namespace GMailProj.Workflow.Login.Steps
{
    [Binding]
    public class LoginSteps
    {
        private readonly LoginPage _loginPage;
        private readonly ComposeMailPage _composeMailPage;
        private readonly LoginContext _loginContext;
        //private readonly DataResolver _dataResolver;
        public LoginSteps(LoginPage loginPage, ComposeMailPage composeMailPage, LoginContext loginContext)
        {
            _loginPage = loginPage;
            _composeMailPage = composeMailPage;
            _loginContext = loginContext;
        }

        [Given(@"I launch the application")]
        public void GivenILaunchTheApplication()
        {
            _loginPage.LaunchApplication();
        }
        
        [When(@"I enter the invalid username")]
        public void WhenIEnterTheInvalidUsername()
        {
            Console.WriteLine("User Logged in: cmiasuif");
            _loginPage.UserNameInputSendKeys("cmiasuif");
        }
        
        [When(@"I click on next")]
        public void WhenIClickOnNext()
        {
            _loginPage.NextButtonClick();
            _loginPage.waitElement();
        }
        
        [When(@"I enter the valid username")]
        public void WhenIEnterTheValidUsername(Table table)
        {
            _loginContext.username = table.Rows[0]["UserName"];
            Console.WriteLine("User Logged in: " + _loginContext.username);
            _loginPage.UserNameInputSendKeys(_loginContext.username);
        }
        
        [When(@"I enter the invalid password")]
        public void WhenIEnterTheInvalidPassword()
        {
            Console.WriteLine("User Logged in: testingpassword");
            _loginPage.PasswordInputSendKeys("testingpassword");
        }
        
        [When(@"I enter the valid password")]
        public void WhenIEnterTheValidPassword(Table table)
        {
            _loginContext.password = table.Rows[0]["Password"];
            Console.WriteLine("User Logged in: " + _loginContext.password);
            _loginPage.PasswordInputSendKeys(_loginContext.password);
        }
        
        [Then(@"I should be shown an invalid username error message ""(.*)""")]
        public void ThenIShouldBeShownAnUserErrorMessage(string userErrMessage)
        {
            Assert.AreEqual(userErrMessage, _loginPage.getInvalidUserErrorMessage(), "The expected error message " + userErrMessage + "do no match with the actual " + _loginPage.getInvalidUserErrorMessage());
        }

       
        [Then(@"I should be shown an invalid password error message ""(.*)""")]
        public void ThenIShouldBeShownAnPassErrorMessage(string userPassMessage)
        {
            Assert.AreEqual(userPassMessage, _loginPage.getInvalidPasswordErrorMessage(), "The expected error message " + userPassMessage + "do no match with the actual " + _loginPage.getInvalidPasswordErrorMessage());
        }

        [Then(@"I should be able to see a compose button")]
        public void ThenIShouldBeAbleToSeeAComposeButton()
        {
           if (_composeMailPage.verifyComposeButtonExists())
                Console.WriteLine("Compose Button exists");
        }
    }
}
