﻿using BoDi;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Text;
using TechTalk.SpecFlow;

namespace GMailProj.Framework
{
    [Binding]
    public class Binding
    {
        private readonly IBrowserSupport _browserSupport;
        private readonly IObjectContainer _objectContainer;

        public Binding(IObjectContainer objectContainer, BrowserSupport browserSupport)
        {
            _objectContainer = objectContainer;
            _browserSupport = browserSupport;
            _objectContainer.RegisterInstanceAs(_browserSupport);
        }
        [BeforeScenario]
        public void SetUpWebDriver()
        {
            var webDriver = _browserSupport.StartBrowser();
            _objectContainer.RegisterInstanceAs(webDriver, null, true);
            WebDriverWait wait = new WebDriverWait(webDriver, TimeSpan.FromSeconds(20));
            _objectContainer.RegisterInstanceAs(wait);
        }

        [AfterScenario]
        public void QuitWebDriver()
        {
            var webDriver = _objectContainer.Resolve<IWebDriver>();
            var scenarioContext = _objectContainer.Resolve<ScenarioContext>();
            try
            {
                if (scenarioContext.TestError != null)
                {
                    _browserSupport.TakeScreenshot(webDriver, TestContext.CurrentContext.Test.ID);
                }
            }
            finally
            {
                _browserSupport.CleanUp(webDriver);
            }
        }

        [AfterStep]
        public void AfterStepOutput()
        {
            var scenarioContext = _objectContainer.Resolve<ScenarioContext>();
            var stepContext = scenarioContext.StepContext;
            string currentStepFullText = $"{stepContext.StepInfo.StepDefinitionType}{stepContext.StepInfo.Text}";
            Console.WriteLine(currentStepFullText);
            var stepTable = stepContext.StepInfo.Table;
            if (stepTable != null && !string.IsNullOrEmpty(stepTable.ToString()))
            {
                Console.WriteLine(stepTable);
            }
            var error = scenarioContext.TestError;
        }
    }
}
