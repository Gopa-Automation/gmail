﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace GMailProj.Framework
{
    public interface IBrowserSupport
    {
        IWebDriver StartBrowser();
        void TakeScreenshot(IWebDriver webDriver, string testId);

        void CleanUp(IWebDriver webDriver);
    }
    public class BrowserSupport : IBrowserSupport
    {
        public IWebDriver StartBrowser()
        {
            IWebDriver webDriver = null;
            var chromeOptions = new ChromeOptions();
            chromeOptions.AddArguments("--disable-extensions");
            chromeOptions.AddArguments("no-sandbox");
            chromeOptions.AddArguments("--window-size=1920,1200");
            string CurrentDirectory = Environment.CurrentDirectory;
            string projectDirectory = Directory.GetParent(CurrentDirectory).Parent.Parent.FullName;
            string fullPath = Path.Combine(projectDirectory, "Drivers");
            webDriver = new ChromeDriver(fullPath, chromeOptions);
            webDriver.Manage().Timeouts().PageLoad = TimeSpan.FromSeconds(30);
            return webDriver;
        }

        public void TakeScreenshot(IWebDriver webDriver, string testId)
        {
            try
            {
                string ResultsPath = Path.Combine(Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName, "Results");
                string fileName = string.Format($"{testId}_{DateTime.Now.ToString("hhmmssff")}.png");
                Screenshot ss = ((ITakesScreenshot)webDriver).GetScreenshot();
                ss.SaveAsFile(ResultsPath + "//" + fileName, ScreenshotImageFormat.Png);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }

        public void CleanUp(IWebDriver webDriver)
        {
            try
            {
                webDriver.Close();
                webDriver.Quit();
            }
            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}
