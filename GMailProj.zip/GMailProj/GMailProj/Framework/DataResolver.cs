﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace GMailProj.Framework
{
    public class DataResolver
    {
        public DataResolver()
        {

        }
        public string Resolve(string key)
        {
            string[] parts;
            if (!TryParseKey(key, out parts))
                return key;
            if (parts.Length < 2)
                throw new ArgumentException("The key provided should be in the format {path.file.property}, with the path . seperated relative to the test execution folder and the file being optional.");
            var propertyName = parts[parts.Length - 1];
            Array.Resize(ref parts, parts.Length - 1);
            string path = null;
           // var o = null;
            try
            {
                string CurrentDirectory = Environment.CurrentDirectory;
                string projectDirectory = Directory.GetParent(CurrentDirectory).Parent.Parent.FullName;
                path = Path.Combine(projectDirectory, "Login", "login.json");
                var o = ReadJsonResouce(path);

                string jvalue = o.GetValue(propertyName).ToString();
                return jvalue;
                
            }
            catch (Exception e)
            {
                throw new InvalidDataException($"unable to find property '{propertyName}' in file '{path}'.", e);
            }
        
            throw new InvalidDataException($"unable to find property '{propertyName}' in file '{path}'.");
        }

        public bool TryParseKey(string key, out string[] parts)
        {
            if (!key.StartsWith("{") || !key.EndsWith("}"))
            {
                parts = null;
                return false;
            }
            parts = key.Substring(1, key.Length - 2).Split('.');

            if (parts.Length == 0)
                throw new ArgumentException("The key provided should be in the format {path.file}, with the path . seperated relative to the test execution folder and the file being optional.");
            return true;
        }

        public JObject ReadJsonResouce(string resoucePath)
        {
            if (resoucePath == null)
                throw new ArgumentException($"resouce not found");
            string json;
            using (var sr = new StreamReader(resoucePath))
            {
                json = sr.ReadToEnd();
                return JObject.Parse(json);
            }

        }

       
    }
}
