﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GMailProj.Config
{
    public class ConfigSetting
    {
        public string AppURL { get; set; }
    }
}
